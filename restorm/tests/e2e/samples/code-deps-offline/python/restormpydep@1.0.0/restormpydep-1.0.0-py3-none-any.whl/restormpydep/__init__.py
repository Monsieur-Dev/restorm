"""Tiny zero-dependency pure-Python package.
Committed fixture for the code-node external-dependencies e2e — never fetched
from a live registry (installed offline via RESTORM_CODE_DEPS_OFFLINE_DIR).
"""
__version__ = "1.0.0"


def greeting():
    return "hello from restormpydep"
